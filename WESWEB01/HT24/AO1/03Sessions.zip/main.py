from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'MuBC1EstEby8rRH6Td2J'

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == '1234':
            session['logged_in'] = True
            return redirect(url_for('secret'))
        else:
            return "Invalid credentials. Please try again.", 401
    else:
        if session['logged_in']:
            return "You are already logged in!", 200
        else:
            return render_template('login.html')

@app.route('/secret')
def secret():
    if session.get('logged_in'):
        return render_template('secret.html')
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
